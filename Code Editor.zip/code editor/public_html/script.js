function runCode() {
    const html = document.getElementById("html-editor").value;
    const css = "<style>" + document.getElementById("css-editor").value + "</style>";
    const js = "<script>" + document.getElementById("js-editor").value + "<\/script>";
    
    const output = document.getElementById("output");
    output.innerHTML = html + css + js;
}
